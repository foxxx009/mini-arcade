/* Candy Blast — match-3 with genuinely 3D candies.
   Candy sprites are ray-marched offline (SDF + Lambert + Blinn-Phong + Fresnel + SSS),
   the board is drawn in perspective, and every candy casts a real drop shadow. */
(function (MA) {
  'use strict';

  var COLS = 8, ROWS = 8, TYPES = 6;
  var SP = { NONE: 0, H: 1, V: 2, BOMB: 3, RAINBOW: 4 };
  var PERSP = 0.085;                 // board perspective: far rows are smaller

  /* base colour / rim colour / rgb string */
  var PAL = [
    { b: [255, 47, 109], l: [255, 190, 214], g: '255,47,109' },   // 0 ball      red
    { b: [255, 138, 31], l: [255, 220, 170], g: '255,138,31' },   // 1 gummy cube orange
    { b: [255, 214, 61], l: [255, 248, 190], g: '255,214,61' },   // 2 star      yellow
    { b: [46, 230, 107], l: [190, 255, 216], g: '46,230,107' },   // 3 gem       green
    { b: [255, 92, 200], l: [255, 205, 238], g: '255,92,200' },   // 4 heart     pink
    { b: [55, 168, 255], l: [190, 230, 255], g: '55,168,255' }    // 5 donut     blue
  ];

  function rand(n) { return Math.floor(Math.random() * n); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function easeOutBack(t) { var c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }

  /* ================= 3D: signed distance fields ================= */
  function sdStar2D(px, py, r, n, m) {
    var an = Math.PI / n, en = Math.PI / m;
    var acs = [Math.cos(an), Math.sin(an)], ecs = [Math.cos(en), Math.sin(en)];
    var bn = (Math.atan2(px, py) % (2 * an) + 2 * an) % (2 * an) - an;
    var len = Math.sqrt(px * px + py * py);
    var x = len * Math.cos(bn), y = len * Math.abs(Math.sin(bn));
    x -= r * acs[0]; y -= r * acs[1];
    var d = -(x * ecs[0] + y * ecs[1]);
    var cl = clamp(d, 0, r * acs[1] / ecs[1]);
    x += ecs[0] * cl; y += ecs[1] * cl;
    return Math.sqrt(x * x + y * y) * (x >= 0 ? 1 : -1);
  }
  function sdHeart2D(px, py) {
    var x = Math.abs(px), y = py;
    if (y + x > 1) {
      var ax = x - 0.25, ay = y - 0.75;
      return Math.sqrt(ax * ax + ay * ay) - Math.sqrt(2) / 4;
    }
    var d1 = Math.sqrt(x * x + (y - 1) * (y - 1));
    var t = Math.max(x + y, 0) * 0.5;
    var d2 = Math.sqrt((x - t) * (x - t) + (y - t) * (y - t));
    return Math.sqrt(Math.min(d1, d2)) * (x - y >= 0 ? 1 : -1);
  }
  function opExtrude(d2, dz) {
    var a = Math.max(d2, 0), b = Math.max(dz, 0);
    return Math.min(Math.max(d2, dz), 0) + Math.sqrt(a * a + b * b);
  }
  function smin(a, b, k) {
    var h = Math.min(Math.max(0.5 + 0.5 * (b - a) / k, 0), 1);
    return b * (1 - h) + a * h - k * h * (1 - h);
  }
  /* approximate ellipsoid, r = [rx, ry, rz] */
  function sdEll(x, y, z, r) {
    var k0 = Math.sqrt((x / r[0]) * (x / r[0]) + (y / r[1]) * (y / r[1]) + (z / r[2]) * (z / r[2]));
    var k1 = Math.sqrt((x / (r[0] * r[0])) * (x / (r[0] * r[0])) + (y / (r[1] * r[1])) * (y / (r[1] * r[1])) + (z / (r[2] * r[2])) * (z / (r[2] * r[2])));
    return k0 * (k0 - 1) / Math.max(k1, 1e-6);
  }

  function sd(x, y, z, type) {
    switch (type) {
      case 0: return Math.sqrt(x * x + y * y + z * z) - 0.415;           // ball
      case 1: {                                                          // rounded gummy cube
        var bx = Math.abs(x) - 0.255, by = Math.abs(y) - 0.255, bz = Math.abs(z) - 0.205;
        var ox = Math.max(bx, 0), oy = Math.max(by, 0), oz = Math.max(bz, 0);
        return Math.sqrt(ox * ox + oy * oy + oz * oz) +
          Math.min(Math.max(bx, Math.max(by, bz)), 0) - 0.115;
      }
      case 2: {                                                          // star prism
        var s2 = sdStar2D(x * 2.55, y * 2.55, 0.95, 5, 2.6) / 2.55;
        return opExtrude(s2, Math.abs(z) - 0.135) - 0.05;
      }
      case 3: {                                                          // cut gem: octahedron puffed by a smooth ellipsoid belly
        var ax = Math.abs(x), ay = Math.abs(y), az = Math.abs(z);
        var oct = (ax + ay + az - 0.375) * 0.52;
        var bel = sdEll(x, y, z, [0.27, 0.27, 0.235]);
        return smin(oct, bel, 0.09);
      }
      case 4: {                                                          // heart prism (domed in shading)
        var h2 = sdHeart2D(x / 0.55, (y + 0.03) / 0.55) * 0.55;
        return opExtrude(h2, Math.abs(z) - 0.15) - 0.06;
      }
      default: {                                                         // donut / torus
        var q = Math.sqrt(x * x + y * y) - 0.275;
        return Math.sqrt(q * q + z * z) - 0.145;
      }
    }
  }

  /* uniform shrink so every shape stays inside the sprite bounds and
     leaves a visible gap between candies (unit half-cell is 0.5) */
  var FIT = 0.90;
  function sdS(x, y, z, type) {
    return sd(x / FIT, y / FIT, z / FIT, type) * FIT;
  }

  var NRM = [0, 0, 0];
  function normalAt(x, y, z, type) {
    var e = 0.0016;
    var dx = sdS(x + e, y, z, type) - sdS(x - e, y, z, type);
    var dy = sdS(x, y + e, z, type) - sdS(x, y - e, z, type);
    var dz = sdS(x, y, z + e, type) - sdS(x, y, z - e, type);
    var l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
    NRM[0] = dx / l; NRM[1] = dy / l; NRM[2] = dz / l;
    return NRM;
  }

  /* light rig */
  var L1 = [-0.40, -0.58, 0.71]; (function () {
    var l = Math.sqrt(L1[0] * L1[0] + L1[1] * L1[1] + L1[2] * L1[2]);
    L1 = [L1[0] / l, L1[1] / l, L1[2] / l];
  })();
  var L2 = [0.62, 0.30, 0.55]; (function () {
    var l = Math.sqrt(L2[0] * L2[0] + L2[1] * L2[1] + L2[2] * L2[2]);
    L2 = [L2[0] / l, L2[1] / l, L2[2] / l];
  })();
  var H1 = (function () {
    var v = [L1[0], L1[1], L1[2] + 1];
    var l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    return [v[0] / l, v[1] / l, v[2] / l];
  })();
  var H2 = (function () {
    var v = [L2[0], L2[1], L2[2] + 1];
    var l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    return [v[0] / l, v[1] / l, v[2] / l];
  })();

  /* ray-march one candy into an offscreen canvas */
  function makeRaySprite(type, logicalPx) {
    try {
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var ss = 1;
      var N = Math.max(24, Math.round(logicalPx * dpr * ss));
      var cvv = document.createElement('canvas');
      cvv.width = N; cvv.height = N;
      var g = cvv.getContext('2d');
      if (!g) return null;
      var img = g.createImageData ? g.createImageData(N, N) : null;
      if (!img || !img.data) return null;
      var d = img.data;
      var base = PAL[type].b, lit = PAL[type].l;

      for (var py = 0; py < N; py++) {
        var oy = 0.5 - (py + 0.5) / N;              // +y is up
        for (var px = 0; px < N; px++) {
          var ox = (px + 0.5) / N - 0.5;
          var o = (py * N + px) * 4;
          d[o + 3] = 0;

          // bounding-disc reject
          var rr = Math.sqrt(ox * ox + oy * oy);
          if (rr > 0.56) continue;

          var z = 0.75, hit = false, minD = 9, i;
          for (i = 0; i < 56; i++) {
            var dd = sdS(ox, oy, z, type);
            if (dd < 0.0009) { hit = true; break; }
            if (dd < minD) minD = dd;
            z -= Math.max(dd * 0.8, 0.0035);
            if (z < -0.75) break;
          }

          var alpha = 0;
          if (hit) alpha = 1;
          else if (minD < 0.011) alpha = 1 - minD / 0.011;   // SDF edge AA
          if (alpha <= 0.003) continue;

          var n = normalAt(ox, oy, z, type);
          var nx = n[0], ny = n[1], nz = n[2];

          /* pillow dome: extruded fronts are geometrically flat, so bend the
             shading normal toward a hemispherical one — gives the puffed-gummy read */
          if (type === 1 || type === 2 || type === 4) {
            var domeR = type === 4 ? 0.34 : 0.42;
            var bw = type === 4 ? 0.92 : 0.85;
            var ux2 = ox / domeR, uy2 = oy / domeR;
            var ul = Math.sqrt(ux2 * ux2 + uy2 * uy2 + 1);
            nx = nx * (1 - bw) + (ux2 / ul) * bw;
            ny = ny * (1 - bw) + (uy2 / ul) * bw;
            nz = nz * (1 - bw) + (1 / ul) * bw;
            var nl2 = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
            nx /= nl2; ny /= nl2; nz /= nl2;
          }

          var diff = Math.max(0, nx * L1[0] + ny * L1[1] + nz * L1[2]);
          var back = Math.max(0, -(nx * L1[0] + ny * L1[1] + nz * L1[2]));
          var sp1 = Math.pow(Math.max(0, nx * H1[0] + ny * H1[1] + nz * H1[2]), 64);
          var sp2 = Math.pow(Math.max(0, nx * H2[0] + ny * H2[1] + nz * H2[2]), 18);
          var fres = Math.pow(1 - Math.max(0, nz), 3.2);
          var amb = 0.26 + 0.30 * (ny * 0.5 + 0.5);
          var bounce = Math.max(0, -ny) * 0.22;              // light bounced off the board
          var stripe = 0.96 + 0.08 * Math.sin(Math.atan2(oy, ox) * 5 + z * 11);

          var shade = (0.30 + 0.92 * diff + amb) * stripe;
          var r = base[0] * shade + lit[0] * (0.55 * back + bounce);
          var gg = base[1] * shade + lit[1] * (0.55 * back + bounce);
          var b = base[2] * shade + lit[2] * (0.55 * back + bounce);

          var s1 = sp1 * 255, s2v = sp2 * 90;
          r += s1 + s2v; gg += s1 + s2v; b += s1 + s2v;

          // fresnel rim: white core + cool environment tint at the silhouette
          r += fres * (150 + 40 * ny);
          gg += fres * (170 + 30 * ny);
          b += fres * (205 + 60 * ny);

          d[o] = clamp(r, 0, 255);
          d[o + 1] = clamp(gg, 0, 255);
          d[o + 2] = clamp(b, 0, 255);
          d[o + 3] = Math.round(alpha * 255);
        }
      }
      g.putImageData(img, 0, 0);
      return cvv;
    } catch (e) { return null; }
  }

  /* flat fallback (also used until the ray-march finishes) */
  function makeFlatSprite(type, px) {
    try {
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var cvv = document.createElement('canvas');
      cvv.width = Math.max(2, Math.round(px * dpr));
      cvv.height = Math.max(2, Math.round(px * dpr));
      var g = cvv.getContext('2d');
      if (!g) return null;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      var s = px, c = s / 2, p = PAL[type];
      var col = 'rgb(' + p.b[0] + ',' + p.b[1] + ',' + p.b[2] + ')';
      var lcol = 'rgb(' + p.l[0] + ',' + p.l[1] + ',' + p.l[2] + ')';
      var gr = g.createRadialGradient(c - s * 0.2, c - s * 0.24, s * 0.03, c, c, s * 0.46);
      gr.addColorStop(0, lcol); gr.addColorStop(0.45, col); gr.addColorStop(1, 'rgba(0,0,0,.65)');
      g.fillStyle = gr;
      g.beginPath(); g.arc(c, c, s * 0.42, 0, Math.PI * 2); g.fill();
      g.fillStyle = 'rgba(255,255,255,.75)';
      g.beginPath(); g.ellipse(c - s * 0.13, c - s * 0.18, s * 0.11, s * 0.07, -0.5, 0, Math.PI * 2); g.fill();
      return cvv;
    } catch (e) { return null; }
  }

  /* ---------- Playgama Bridge: ad helpers (safe no-op when bridge absent) ----------
     Every call is guarded so the public site (no Bridge SDK) is completely unaffected. */
  MA.bridgeShowInterstitial = function (placement) {
    var b = window.bridge;
    if (!b || !b.advertisement || !b.advertisement.isInterstitialSupported) return false;
    try { b.advertisement.showInterstitial(placement || 'game_over'); return true; } catch (e) { return false; }
  };
  MA.bridgeShowRewarded = function (placement, onReward) {
    var b = window.bridge;
    if (!b || !b.advertisement || !b.advertisement.isRewardedSupported) return false;
    try {
      b.advertisement.on(b.EVENT_NAME.REWARDED_STATE_CHANGED, function (st) {
        if (st === 'rewarded') { try { if (onReward) onReward(); } catch (e) { } }
      });
      b.advertisement.showRewarded(placement || 'continue');
      return true;
    } catch (e) { return false; }
  };

  MA.startMatch3 = function (host) {
    host.innerHTML = '';

    var CELL = 40, PAD = 9, BW = 0, BH = 0, W = 0, H = 0, ctx = null;
    var sprites = [], spriteFor = 0, rowY = [];

    var cv = document.createElement('canvas');
    cv.className = 'board3d';
    host.appendChild(cv);

    var hud = MA.el('div', 'hud stat3');
    host.appendChild(hud);

    var goalWrap = MA.el('div', 'goalwrap');
    var goalTxt = MA.el('div', 'goaltxt');
    var bar = MA.el('div', 'goalbar');
    var fill = MA.el('div', 'goalfill');
    bar.appendChild(fill);
    goalWrap.appendChild(goalTxt);
    goalWrap.appendChild(bar);
    host.appendChild(goalWrap);

    var hint = MA.el('div', 'hint', 'Swap two candies to match 3 or more');
    host.appendChild(hint);

    var row = MA.el('div', 'row');
    host.appendChild(row);

    /* ---------- geometry ---------- */
    function rowS(r) { return 1 - PERSP * (r / (ROWS - 1)); }
    function computeRows() {
      rowY = [];
      var y = 0;
      for (var r = 0; r < ROWS; r++) { rowY.push(y); y += CELL * rowS(r); }
      BH = y;
    }
    function rowH(r) { return CELL * rowS(r); }
    function rowW(r) { return CELL * rowS(r); }
    function rowX0(r) { return (BW - rowW(r) * COLS) / 2; }
    function cellCX(r, c) { return rowX0(r) + c * rowW(r) + rowW(r) / 2; }
    function cellCY(r) { return rowY[r] + rowH(r) / 2; }

    // ---------- state ----------
    var grid = [], particles = [], floaters = [], rings = [], beams = [], flashes = [];
    var score = 0, level = 1, moves = 25, target = 1500;
    var combo = 0, state = 'idle', shake = 0, banner = null, flashAll = 0;
    var sel = null, swapPair = null, spawns = [], forceClear = null;
    var lastTouched = null, drag = null, dead = false, sound = true, paused = false;
    var raf = 0, actx = null;

    var still = false;
    try { still = window.location.search.indexOf('still') >= 0; } catch (e) { }

    function idx(r, c) { return r * COLS + c; }

    function newTile(r, c, py) {
      return {
        t: rand(TYPES), sp: SP.NONE,
        px: cellCX(r, c), py: py != null ? py : -CELL,
        vx: 0, vy: 0, sx: 1, sy: 1, rot: 0, hop: 0, die: 0
      };
    }

    function build() {
      grid = [];
      for (var r = 0; r < ROWS; r++) {
        grid[r] = [];
        for (var c = 0; c < COLS; c++) grid[r][c] = newTile(r, c, still ? cellCY(r) : cellCY(r) - CELL * (ROWS - r) * 0.7 - CELL);
      }
      var guard = 0;
      while (findMatches().length && guard++ < 300) {
        var m = findMatches()[0];
        for (var i = 0; i < m.cells.length; i++) grid[m.cells[i].r][m.cells[i].c].t = rand(TYPES);
      }
    }

    // ---------- matching ----------
    function runs() {
      var out = [], r, c, len;
      for (r = 0; r < ROWS; r++) {
        len = 1;
        for (c = 1; c <= COLS; c++) {
          var same = c < COLS && grid[r][c] && grid[r][c - 1] &&
            grid[r][c].t === grid[r][c - 1].t && !grid[r][c].die && !grid[r][c - 1].die;
          if (same) len++;
          else {
            if (len >= 3) { var cells = []; for (var k = 0; k < len; k++) cells.push({ r: r, c: c - len + k }); out.push({ cells: cells, dir: 'h' }); }
            len = 1;
          }
        }
      }
      for (c = 0; c < COLS; c++) {
        len = 1;
        for (r = 1; r <= ROWS; r++) {
          var same2 = r < ROWS && grid[r][c] && grid[r - 1][c] &&
            grid[r][c].t === grid[r - 1][c].t && !grid[r][c].die && !grid[r - 1][c].die;
          if (same2) len++;
          else {
            if (len >= 3) { var cells2 = []; for (var k2 = 0; k2 < len; k2++) cells2.push({ r: r - len + k2, c: c }); out.push({ cells: cells2, dir: 'v' }); }
            len = 1;
          }
        }
      }
      return out;
    }

    function findMatches() {
      var rs = runs();
      if (!rs.length) return [];
      var groups = [], used = new Array(rs.length).fill(false);
      for (var i = 0; i < rs.length; i++) {
        if (used[i]) continue;
        var set = {}, cells = [], dirs = {}, maxLen = 0, stack = [i];
        used[i] = true;
        while (stack.length) {
          var j = stack.pop();
          dirs[rs[j].dir] = true;
          maxLen = Math.max(maxLen, rs[j].cells.length);
          for (var k = 0; k < rs[j].cells.length; k++) {
            var cell = rs[j].cells[k], key = idx(cell.r, cell.c);
            if (!set[key]) { set[key] = true; cells.push(cell); }
          }
          for (var m = 0; m < rs.length; m++) {
            if (used[m]) continue;
            for (var n = 0; n < rs[m].cells.length; n++) {
              if (set[idx(rs[m].cells[n].r, rs[m].cells[n].c)]) { used[m] = true; stack.push(m); break; }
            }
          }
        }
        groups.push({ cells: cells, maxLen: maxLen, cross: Object.keys(dirs).length > 1 });
      }
      return groups;
    }

    function specialFor(g) {
      if (g.maxLen >= 5) return SP.RAINBOW;
      if (g.cross) return SP.BOMB;
      if (g.maxLen === 4) return g.cells[0].r === g.cells[1].r ? SP.V : SP.H;
      return SP.NONE;
    }

    function collectClear(seeds) {
      var seen = {}, out = [], queue = seeds.slice(), guard = 0;
      while (queue.length && guard++ < 900) {
        var cell = queue.shift(), key = idx(cell.r, cell.c);
        if (seen[key]) continue;
        if (cell.r < 0 || cell.r >= ROWS || cell.c < 0 || cell.c >= COLS) continue;
        seen[key] = true;
        var tile = grid[cell.r][cell.c];
        if (!tile || tile.die) continue;
        out.push(cell);
        if (tile.sp === SP.H || tile.sp === SP.V) {
          if (tile.sp === SP.H) { for (var c = 0; c < COLS; c++) queue.push({ r: cell.r, c: c }); beam('h', cell.r, tile.t); }
          else { for (var r = 0; r < ROWS; r++) queue.push({ r: r, c: cell.c }); beam('v', cell.c, tile.t); }
        } else if (tile.sp === SP.BOMB) {
          for (var dr = -1; dr <= 1; dr++) for (var dc = -1; dc <= 1; dc++) queue.push({ r: cell.r + dr, c: cell.c + dc });
          boom(cellCX(cell.r, cell.c), cellCY(cell.r));
        } else if (tile.sp === SP.RAINBOW) {
          var t = tile.t;
          for (var rr = 0; rr < ROWS; rr++) for (var cc = 0; cc < COLS; cc++) {
            if (grid[rr][cc] && grid[rr][cc].t === t) queue.push({ r: rr, c: cc });
          }
          rainwave(cellCX(cell.r, cell.c), cellCY(cell.r));
        }
      }
      return out;
    }

    // ---------- flow ----------
    function doSwap(a, b, back) {
      var t = grid[a.r][a.c];
      grid[a.r][a.c] = grid[b.r][b.c];
      grid[b.r][b.c] = t;
      state = back ? 'swapback' : 'swap';
      swapPair = [a, b];
    }

    function resolve() {
      if (forceClear) {
        var pair = forceClear; forceClear = null;
        if (state === 'swap') { moves--; swapPair = null; }
        combo++;
        seedRainbow(pair);
        return;
      }
      var groups = findMatches();
      if (!groups.length) {
        if (state === 'swap') { doSwap(swapPair[0], swapPair[1], true); sel = null; return; }
        state = 'idle'; swapPair = null;
        endOfCascade();
        return;
      }
      if (state === 'swap') { moves--; swapPair = null; }
      combo++;
      var seed = [], spawn = [];
      for (var i = 0; i < groups.length; i++) {
        var g = groups[i], sp = specialFor(g);
        if (sp !== SP.NONE) {
          var at = pickSpawnCell(g);
          spawn.push({ r: at.r, c: at.c, sp: sp });
          for (var k = 0; k < g.cells.length; k++) {
            if (!(g.cells[k].r === at.r && g.cells[k].c === at.c)) seed.push(g.cells[k]);
          }
        } else seed = seed.concat(g.cells);
      }
      clearCells(seed, spawn);
    }

    function seedRainbow(pair) {
      var a = pair[0], b = pair[1];
      var ta = grid[a.r][a.c], tb = grid[b.r][b.c];
      if (!ta || !tb) { state = 'idle'; return; }
      var rc = ta.sp === SP.RAINBOW ? a : b;
      var oc = rc === a ? b : a;
      grid[rc.r][rc.c].t = grid[oc.r][oc.c].t;
      clearCells([rc, oc], []);
    }

    function clearCells(seed, spawn) {
      var cells = collectClear(seed);
      var reserved = {};
      (spawn || []).forEach(function (s) { reserved[idx(s.r, s.c)] = true; });
      cells = cells.filter(function (c) { return !reserved[idx(c.r, c.c)]; });
      if (!cells.length) {
        (spawn || []).forEach(function (s) {
          var t = grid[s.r][s.c];
          if (t) { t.sp = s.sp; t.sx = t.sy = 1.35; }
        });
        if (state === 'swap') { doSwap(swapPair[0], swapPair[1], true); sel = null; return; }
        state = 'idle'; endOfCascade(); return;
      }

      var gained = Math.round(30 * cells.length * (1 + 0.55 * (combo - 1)));
      score += gained;
      MA.setBest('match3', score);

      cells.forEach(function (c) {
        var tile = grid[c.r][c.c];
        if (!tile) return;
        tile.die = 0.001;
        burst(cellCX(c.r, c.c), cellCY(c.r), PAL[tile.t], 8 + Math.min(combo, 4));
      });

      (spawn || []).forEach(function (s) {
        var tile = grid[s.r][s.c];
        if (!tile) return;
        tile.sp = s.sp; tile.sx = tile.sy = 1.5;
        rings.push({ x: cellCX(s.r, s.c), y: cellCY(s.r), r: CELL * 0.2, max: CELL * 1.5, life: 1, col: '255,255,255', lw: 5 });
        floaters.push({ x: cellCX(s.r, s.c), y: cellCY(s.r), text: spName(s.sp), life: 1, col: '#fff', sz: 0.34, pop: true });
      });

      if (cells.length) {
        var mid = cells[Math.floor(cells.length / 2)];
        floaters.push({
          x: cellCX(mid.r, mid.c), y: cellCY(mid.r),
          text: '+' + gained, life: 1, col: '#fff', sz: 0.44, pop: true
        });
        shake = Math.max(shake, Math.min(3 + cells.length * 0.7, 12));
        if (combo > 1) {
          banner = { text: comboWord(combo), life: 1, age: 0 };
          shake = Math.max(shake, Math.min(5 + combo * 2, 16));
          flashAll = Math.min(0.35, 0.08 * combo);
        }
      }

      beep(420 + Math.min(combo, 8) * 85, 0.1, 'triangle');
      state = 'clearing';
      spawns = spawn || [];
      setHud();
    }

    function spName(sp) {
      return sp === SP.BOMB ? 'BOMB!' : sp === SP.RAINBOW ? 'RAINBOW!' : 'STRIPED!';
    }
    function comboWord(n) {
      return n >= 6 ? 'INSANE!' : n === 5 ? 'UNBELIEVABLE!' : n === 4 ? 'AMAZING!' : n === 3 ? 'GREAT!' : 'NICE!';
    }
    function pickSpawnCell(g) {
      if (lastTouched) {
        for (var i = 0; i < g.cells.length; i++) {
          if (g.cells[i].r === lastTouched.r && g.cells[i].c === lastTouched.c) return g.cells[i];
        }
      }
      return g.cells[Math.floor(g.cells.length / 2)];
    }

    function applyGravity() {
      for (var c = 0; c < COLS; c++) {
        var write = ROWS - 1;
        for (var r = ROWS - 1; r >= 0; r--) {
          if (grid[r][c]) {
            if (write !== r) { grid[write][c] = grid[r][c]; grid[r][c] = null; }
            write--;
          }
        }
        var above = 1;
        for (var rr = write; rr >= 0; rr--) {
          grid[rr][c] = newTile(rr, c, cellCY(rr) - CELL * above * 0.95 - CELL * 0.5);
          grid[rr][c].vy = 1.2;
          above++;
        }
      }
      state = 'falling';
    }

    function endOfCascade() {
      combo = 0;
      if (score >= target) { levelUp(); return; }
      if (moves <= 0) { gameOver(); return; }
      if (!hasMove()) {
        state = 'idle';
        hint.textContent = 'No moves left — shuffling…';
        setTimeout(function () {
          build();
          hint.textContent = 'Swap two candies to match 3 or more';
          setHud();
        }, 650);
      }
    }

    function levelUp() {
      level++;
      moves = 25;
      target = score + 1500 + (level - 1) * 700;
      banner = { text: 'LEVEL ' + level, life: 1.5, age: 0 };
      shake = 12; flashAll = 0.5;
      beep(660, 0.12, 'sine');
      setTimeout(function () { beep(880, 0.16, 'sine'); }, 110);
      setTimeout(function () { beep(1180, 0.2, 'sine'); }, 220);
      setHud();
    }

    function gameOver() {
      dead = true;
      MA.setBest('match3', score);
      setHud();
      hint.textContent = 'Out of moves — final score ' + score + ' at level ' + level + '.';
      row.innerHTML = '';
      // Rewarded "continue": +5 moves (only shown when the platform supports rewarded ads).
      var b = window.bridge;
      if (b && b.advertisement && b.advertisement.isRewardedSupported) {
        row.appendChild(MA.button('🎁 Watch ad · +5 moves', function () {
          MA.bridgeShowRewarded('continue', function () {
            moves += 5; dead = false; paused = false;
            hint.textContent = 'Ad bonus — +5 moves! Keep going.';
            row.innerHTML = '';
            row.appendChild(MA.button('Restart', function () { reset(); }));
            row.appendChild(soundBtn());
            setHud();
          });
        }));
      }
      row.appendChild(MA.button('Play again', function () { reset(); }, true));
      row.appendChild(soundBtn());
      beep(180, 0.35, 'sawtooth');
      MA.onRoundEnd();
      MA.bridgeShowInterstitial('game_over'); // required for revenue share; no-op off-platform
    }

    function soundBtn() {
      return MA.button(sound ? '🔊 Sound on' : '🔇 Sound off', function () {
        sound = !sound;
        this.textContent = sound ? '🔊 Sound on' : '🔇 Sound off';
      });
    }

    function reset() {
      score = 0; level = 1; moves = 25; target = 1500; combo = 0;
      state = 'idle'; dead = false; sel = null; swapPair = null; forceClear = null;
      particles = []; floaters = []; rings = []; beams = []; flashes = [];
      banner = null; shake = 0; flashAll = 0;
      row.innerHTML = '';
      row.appendChild(MA.button('Restart', function () { reset(); }));
      row.appendChild(soundBtn());
      hint.textContent = 'Swap two candies to match 3 or more';
      build(); setHud();
    }

    function hasMove() {
      function trySwap(r1, c1, r2, c2) {
        var a = grid[r1][c1], b = grid[r2][c2];
        if (!a || !b) return false;
        if (a.sp === SP.RAINBOW || b.sp === SP.RAINBOW) return true;
        grid[r1][c1] = b; grid[r2][c2] = a;
        var ok = findMatches().length > 0;
        grid[r1][c1] = a; grid[r2][c2] = b;
        return ok;
      }
      for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
        if (c + 1 < COLS && trySwap(r, c, r, c + 1)) return true;
        if (r + 1 < ROWS && trySwap(r, c, r + 1, c)) return true;
      }
      return false;
    }

    // ---------- fx ----------
    function burst(x, y, pal, n) {
      for (var i = 0; i < n; i++) {
        var a = Math.random() * Math.PI * 2, s = 1.4 + Math.random() * 4.2;
        particles.push({
          x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 1.6,
          life: 1, col: pal.g, r: 1.6 + Math.random() * 3.2,
          rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.4, sq: Math.random() < 0.4
        });
      }
      rings.push({ x: x, y: y, r: CELL * 0.18, max: CELL * 0.95, life: 1, col: pal.g, lw: 4 });
      flashes.push({ x: x, y: y, r: CELL * 0.5, life: 1 });
    }
    function boom(x, y) {
      rings.push({ x: x, y: y, r: CELL * 0.2, max: CELL * 2.1, life: 1, col: '255,220,120', lw: 7 });
      rings.push({ x: x, y: y, r: CELL * 0.1, max: CELL * 1.4, life: 1, col: '255,255,255', lw: 4 });
      flashes.push({ x: x, y: y, r: CELL * 1.5, life: 1 });
      shake = Math.max(shake, 13);
    }
    function rainwave(x, y) {
      for (var i = 0; i < 6; i++) {
        rings.push({ x: x, y: y, r: CELL * 0.2, max: CELL * (2 + i * 0.7), life: 1, col: PAL[i].g, lw: 5, d: i * 3 });
      }
      flashes.push({ x: x, y: y, r: CELL * 2.2, life: 1 });
      shake = Math.max(shake, 14);
    }
    function beam(dir, at, t) {
      beams.push({ dir: dir, at: at, t: t, life: 1 });
      shake = Math.max(shake, 9);
    }

    function beep(freq, dur, type) {
      if (!sound) return;
      try {
        if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
        var o = actx.createOscillator(), g = actx.createGain();
        o.type = type || 'triangle';
        o.frequency.setValueAtTime(freq, actx.currentTime);
        g.gain.setValueAtTime(0.0001, actx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.07, actx.currentTime + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
        o.connect(g); g.connect(actx.destination);
        o.start(); o.stop(actx.currentTime + dur + 0.02);
      } catch (e) { sound = false; }
    }

    // ---------- input ----------
    function cellAt(x, y) {
      for (var r = 0; r < ROWS; r++) {
        var h = rowH(r);
        if (y >= rowY[r] && y < rowY[r] + h) {
          var w = rowW(r), x0 = rowX0(r);
          var c = Math.floor((x - x0) / w);
          if (c < 0 || c >= COLS) return null;
          return { r: r, c: c };
        }
      }
      return null;
    }
    function localXY(e) {
      var b = cv.getBoundingClientRect();
      var sx = b.width ? W / b.width : 1, sy = b.height ? H / b.height : 1;
      return { x: (e.clientX - b.left) * sx - PAD, y: (e.clientY - b.top) * sy - PAD };
    }
    function adjacent(a, b) { return Math.abs(a.r - b.r) + Math.abs(a.c - b.c) === 1; }

    function tryMove(a, b) {
      if (state !== 'idle' || dead) return;
      lastTouched = b;
      var ta = grid[a.r][a.c], tb = grid[b.r][b.c];
      if (!ta || !tb) return;
      if (ta.sp === SP.RAINBOW || tb.sp === SP.RAINBOW) forceClear = [a, b];
      doSwap(a, b, false);
      beep(560, 0.05, 'sine');
    }

    cv.addEventListener('pointerdown', function (e) {
      var p = localXY(e), cell = cellAt(p.x, p.y);
      if (!cell || state !== 'idle' || dead) return;
      if (sel && adjacent(sel, cell)) { var a = sel; sel = null; tryMove(a, cell); return; }
      sel = cell; drag = { from: cell, x: p.x, y: p.y };
      beep(320, 0.03, 'sine');
    });
    cv.addEventListener('pointermove', function (e) {
      if (!drag || state !== 'idle' || dead) return;
      var p = localXY(e), dx = p.x - drag.x, dy = p.y - drag.y;
      if (Math.abs(dx) < CELL * 0.42 && Math.abs(dy) < CELL * 0.42) return;
      var to = { r: drag.from.r, c: drag.from.c };
      if (Math.abs(dx) > Math.abs(dy)) to.c += dx > 0 ? 1 : -1; else to.r += dy > 0 ? 1 : -1;
      if (to.r < 0 || to.r >= ROWS || to.c < 0 || to.c >= COLS) { drag = null; sel = null; return; }
      var a = drag.from; drag = null; sel = null;
      tryMove(a, to);
    });
    cv.addEventListener('pointerup', function () { drag = null; });
    cv.addEventListener('pointerleave', function () { drag = null; });

    // ---------- hud ----------
    function stat(label, val, hot) {
      var s = MA.el('span', 'st' + (hot ? ' hot' : ''));
      s.appendChild(MA.el('i', null, label));
      s.appendChild(MA.el('b', null, String(val)));
      return s;
    }
    function setHud() {
      hud.innerHTML = '';
      hud.appendChild(stat('Level', level));
      hud.appendChild(stat('Score', score, score >= target));
      hud.appendChild(stat('Moves', moves, moves <= 5));
      var pct = clamp(Math.round((score / target) * 100), 0, 100);
      fill.style.width = pct + '%';
      goalTxt.textContent = pct >= 100 ? 'Target cleared!' : score + ' / ' + target + ' to next level';
    }

    // ---------- sprites ----------
    var spriteInfo = [];
    function measureSprite(cv) {                 // fraction of the sprite width that is opaque
      try {
        var n = cv.width, g2 = cv.getContext('2d');
        var d2 = g2.getImageData(0, 0, n, n).data;
        var x0 = n, x1 = -1, y0 = n, y1 = -1;
        for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) {
          if (d2[(y * n + x) * 4 + 3] > 8) {
            if (x < x0) x0 = x; if (x > x1) x1 = x;
            if (y < y0) y0 = y; if (y > y1) y1 = y;
          }
        }
        return x1 < 0 ? null : { w: (x1 - x0 + 1) / n, h: (y1 - y0 + 1) / n };
      } catch (e) { return null; }
    }
    function buildSprites() {
      sprites = [];
      for (var i = 0; i < TYPES; i++) sprites.push(makeFlatSprite(i, CELL));
      spriteFor = CELL;
      var i2 = 0, token = CELL;
      (function next() {
        if (token !== spriteFor) return;          // size changed, abandon
        if (i2 >= TYPES) return;
        var t = i2++;
        try {
          var s = makeRaySprite(t, CELL);
          if (s) { sprites[t] = s; spriteInfo[t] = measureSprite(s); }
        } catch (e) { }
        setTimeout(next, 16);
      })();
    }

    // ---------- drawing ----------
    function rr(g, x, y, w, h, r) {
      g.beginPath();
      g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
      g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
    }

    function drawBackdrop(now) {
      var t = now / 1000;
      for (var i = 0; i < 3; i++) {
        var a = t * (0.16 + i * 0.05) + i * 2.1;
        var x = W * (0.5 + 0.34 * Math.cos(a));
        var y = H * (0.5 + 0.34 * Math.sin(a * 1.3 + i));
        var rad = W * (0.34 + 0.06 * Math.sin(t * 0.7 + i));
        var gr = ctx.createRadialGradient(x, y, 0, x, y, rad);
        gr.addColorStop(0, 'rgba(' + PAL[i * 2].g + ',.16)');
        gr.addColorStop(1, 'rgba(' + PAL[i * 2].g + ',0)');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
      }
    }

    function drawFrame() {
      // metal frame
      rr(ctx, PAD * 0.28, PAD * 0.28, BW + PAD * 1.44, BH + PAD * 1.44, PAD * 0.95);
      var fg = ctx.createLinearGradient(0, 0, 0, BH + PAD * 2);
      fg.addColorStop(0, '#9aa2e2'); fg.addColorStop(0.13, '#525a94');
      fg.addColorStop(0.72, '#252a56'); fg.addColorStop(1, '#646cb0');
      ctx.fillStyle = fg; ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 1.5; ctx.stroke();

      // bezel
      rr(ctx, PAD * 0.72, PAD * 0.72, BW + PAD * 0.56, BH + PAD * 0.56, PAD * 0.62);
      ctx.fillStyle = '#0c0f26'; ctx.fill();

      // board well (trapezoid: top row is narrower)
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(rowX0(0), rowY[0]);
      ctx.lineTo(rowX0(0) + rowW(0) * COLS, rowY[0]);
      ctx.lineTo(rowX0(ROWS - 1) + rowW(ROWS - 1) * COLS, BH);
      ctx.lineTo(rowX0(ROWS - 1), BH);
      ctx.closePath();
      var bg2 = ctx.createLinearGradient(0, 0, BW * 0.4, BH);
      bg2.addColorStop(0, '#2c1656'); bg2.addColorStop(0.55, '#1b1040'); bg2.addColorStop(1, '#110a2e');
      ctx.fillStyle = bg2; ctx.fill();
      ctx.clip();

      // recessed cells
      for (var r = 0; r < ROWS; r++) {
        var h = rowH(r), w = rowW(r), x0 = rowX0(r), y0 = rowY[r];
        for (var c = 0; c < COLS; c++) {
          var cx0 = x0 + c * w;
          rr(ctx, cx0 + 1.5, y0 + 1.5, w - 3, h - 3, w * 0.22);
          ctx.fillStyle = (r + c) % 2 ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.02)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,.36)'; ctx.lineWidth = 2; ctx.stroke();
          ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(cx0 + 3, y0 + h - 3.5); ctx.lineTo(cx0 + w - 3, y0 + h - 3.5); ctx.stroke();
        }
      }
      var sh = ctx.createLinearGradient(0, 0, BW * 0.85, BH * 0.85);
      sh.addColorStop(0, 'rgba(255,255,255,.1)');
      sh.addColorStop(0.42, 'rgba(255,255,255,.02)');
      sh.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = sh; ctx.fillRect(0, 0, BW, BH);
      ctx.restore();
    }

    /* real drop shadow: grows and fades the higher the candy floats */
    function drawShadow(t, r) {
      if (t.die > 0) return;
      var gy = cellCY(r);
      var hgt = Math.max(0, gy - t.py);
      var k = Math.min(1, hgt / (CELL * 1.7));
      var w = rowW(r) * (0.66 - 0.2 * k);
      var cx = t.px + hgt * 0.10, cy = gy + rowH(r) * 0.26;
      var a = 0.5 * (1 - k * 0.72);
      if (a <= 0.02) return;
      var gg = ctx.createRadialGradient(cx, cy, 0, cx, cy, w * 0.72);
      gg.addColorStop(0, 'rgba(0,0,0,' + a.toFixed(3) + ')');
      gg.addColorStop(0.6, 'rgba(0,0,0,' + (a * 0.45).toFixed(3) + ')');
      gg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gg;
      ctx.save();
      ctx.translate(cx, cy); ctx.scale(1, 0.62); ctx.translate(-cx, -cy);
      ctx.beginPath(); ctx.arc(cx, cy, w * 0.72, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }

    function drawSpecial(t, r, x, y, w, now) {
      var c = w / 2;
      if (t.sp === SP.H || t.sp === SP.V) {
        var flow = (now / 260) % 1;
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        for (var k = 0; k < 2; k++) {
          var off = (flow + k * 0.5) % 1;
          ctx.globalAlpha = 0.5 * (1 - Math.abs(off - 0.5) * 1.2);
          ctx.fillStyle = '#fff';
          if (t.sp === SP.H) ctx.fillRect(x, y + c - w * 0.1 + (off - 0.5) * w * 0.3, w, w * 0.2);
          else ctx.fillRect(x + c - w * 0.1 + (off - 0.5) * w * 0.3, y, w * 0.2, w);
        }
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = 'rgba(255,255,255,.85)';
        if (t.sp === SP.H) ctx.fillRect(x + 2, y + c - 1.5, w - 4, 3);
        else ctx.fillRect(x + c - 1.5, y + 2, 3, w - 4);
        ctx.restore();
      } else if (t.sp === SP.BOMB) {
        var pu = 0.5 + 0.5 * Math.sin(now / 150);
        ctx.save();
        ctx.translate(x + c, y + c);
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.5 + pu * 0.5).toFixed(2) + ')';
        ctx.lineWidth = w * 0.07;
        ctx.beginPath(); ctx.arc(0, 0, w * (0.3 + pu * 0.07), 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,225,140,.85)'; ctx.lineWidth = w * 0.05;
        ctx.beginPath(); ctx.arc(0, 0, w * 0.2, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(0, 0, w * 0.075, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      } else if (t.sp === SP.RAINBOW) {
        ctx.save();
        ctx.translate(x + c, y + c);
        ctx.rotate(now / 420);
        var seg = 12;
        for (var i = 0; i < seg; i++) {
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.arc(0, 0, w * 0.46, (Math.PI * 2 / seg) * i, (Math.PI * 2 / seg) * (i + 1.1));
          ctx.closePath();
          ctx.fillStyle = 'rgba(' + PAL[i % 6].g + ',.85)';
          ctx.fill();
        }
        ctx.globalCompositeOperation = 'lighter';
        var gl = ctx.createRadialGradient(0, 0, 0, 0, 0, w * 0.45);
        gl.addColorStop(0, 'rgba(255,255,255,.9)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = gl;
        ctx.beginPath(); ctx.arc(0, 0, w * 0.45, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
    }

    function drawTile(t, r, now) {
      if (!t) return;
      var sp = sprites[t.t] || sprites[0];
      if (!sp) return;
      var w = rowW(r) * t.sx;
      // the heart's visual centroid sits high in its sprite; nudge the sprite
      // down so the heart reads centred inside its cell (measured ~0.27*cell off)
      var yoff = (t.t === 4) ? rowW(r) * 0.27 : 0;
      var bx = t.px, by = t.py - t.hop + yoff;

      if (t.die > 0) {
        var p = t.die;
        var sc = p < 0.35 ? 1 + p * 1.1 : 1.385 * (1 - (p - 0.35) / 0.65);
        if (sc <= 0) return;
        ctx.save();
        ctx.globalAlpha = p < 0.35 ? 1 : 1 - (p - 0.35) / 0.65;
        ctx.translate(bx, by);
        ctx.rotate((p - 0.35) * 1.2);
        ctx.scale(sc, sc);
        ctx.drawImage(sp, -w / 2, -w / 2, w, w);
        if (p < 0.42) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = (1 - p / 0.42) * 0.85;
          ctx.drawImage(sp, -w / 2, -w / 2, w, w);
        }
        ctx.restore();
        return;
      }

      // aura under the selected candy
      if (sel && state === 'idle' && grid[sel.r] && grid[sel.r][sel.c] === t) {
        var pu2 = 0.6 + 0.4 * Math.sin(now / 150);
        var ag = ctx.createRadialGradient(bx, by, 0, bx, by, rowW(r) * 0.85);
        ag.addColorStop(0, 'rgba(255,255,255,' + (0.32 * pu2).toFixed(2) + ')');
        ag.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = ag;
        ctx.fillRect(bx - w, by - w, w * 2, w * 2);
      }

      ctx.save();
      ctx.translate(bx, by);
      ctx.scale(1, t.sy / t.sx);
      if (t.sp !== SP.NONE) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        var g2 = ctx.createRadialGradient(0, 0, 0, 0, 0, w * 0.75);
        g2.addColorStop(0, 'rgba(255,255,255,.3)');
        g2.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g2;
        ctx.fillRect(-w, -w, w * 2, w * 2);
        ctx.restore();
      }
      ctx.drawImage(sp, -w / 2, -w / 2, w, w);
      if (t.sp !== SP.NONE) drawSpecial(t, r, -w / 2, -w / 2, w, now);
      ctx.restore();
    }

    function draw(now) {
      if (!ctx) return;
      ctx.clearRect(0, 0, W, H);
      drawBackdrop(now);

      ctx.save();
      if (shake > 0.4) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
      drawFrame();

      ctx.save();
      ctx.translate(PAD, PAD);
      ctx.beginPath();
      ctx.moveTo(rowX0(0), 0);
      ctx.lineTo(rowX0(0) + rowW(0) * COLS, 0);
      ctx.lineTo(BW, BH); ctx.lineTo(0, BH);
      ctx.closePath();
      ctx.clip();

      // beams
      for (var b = 0; b < beams.length; b++) {
        var bm = beams[b], a = Math.max(0, bm.life);
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        var col = PAL[bm.t].g;
        if (bm.dir === 'h') {
          var yA = rowY[bm.at], hA = rowH(bm.at);
          var lg = ctx.createLinearGradient(0, yA, 0, yA + hA);
          lg.addColorStop(0, 'rgba(' + col + ',0)');
          lg.addColorStop(0.5, 'rgba(255,255,255,' + (0.85 * a).toFixed(2) + ')');
          lg.addColorStop(1, 'rgba(' + col + ',0)');
          ctx.fillStyle = lg;
          ctx.fillRect(rowX0(bm.at), yA + hA * 0.16, rowW(bm.at) * COLS, hA * 0.68);
        } else {
          var wt = rowW(0), wb = rowW(ROWS - 1);
          var xt = rowX0(0) + bm.at * wt, xb = rowX0(ROWS - 1) + bm.at * wb;
          var lg2 = ctx.createLinearGradient(xt, 0, xt + wt, 0);
          lg2.addColorStop(0, 'rgba(' + col + ',0)');
          lg2.addColorStop(0.5, 'rgba(255,255,255,' + (0.85 * a).toFixed(2) + ')');
          lg2.addColorStop(1, 'rgba(' + col + ',0)');
          ctx.fillStyle = lg2;
          ctx.beginPath();
          ctx.moveTo(xt + wt * 0.16, 0); ctx.lineTo(xt + wt * 0.84, 0);
          ctx.lineTo(xb + wb * 0.84, BH); ctx.lineTo(xb + wb * 0.16, BH);
          ctx.closePath(); ctx.fill();
        }
        ctx.restore();
      }

      // shadows first, then candies on top
      for (var r0 = 0; r0 < ROWS; r0++) for (var c0 = 0; c0 < COLS; c0++) {
        if (grid[r0][c0]) drawShadow(grid[r0][c0], r0);
      }
      for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) drawTile(grid[r][c], r, now);

      // rings
      for (var i = 0; i < rings.length; i++) {
        var rg = rings[i];
        if (rg.d > 0) { rg.d--; continue; }
        var pr = 1 - rg.life;
        var rad2 = rg.r + (rg.max - rg.r) * (1 - Math.pow(1 - pr, 2));
        ctx.save();
        ctx.globalAlpha = Math.max(0, rg.life) * 0.85;
        ctx.strokeStyle = 'rgba(' + rg.col + ',1)';
        ctx.lineWidth = Math.max(0.5, rg.lw * rg.life);
        ctx.beginPath(); ctx.arc(rg.x, rg.y, rad2, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
      }

      // flashes
      for (var f = 0; f < flashes.length; f++) {
        var fl = flashes[f], lf = Math.max(0, fl.life);
        var fg2 = ctx.createRadialGradient(fl.x, fl.y, 0, fl.x, fl.y, fl.r * (1.2 - lf * 0.4));
        fg2.addColorStop(0, 'rgba(255,255,255,' + (0.75 * lf).toFixed(2) + ')');
        fg2.addColorStop(0.6, 'rgba(255,240,180,' + (0.25 * lf).toFixed(2) + ')');
        fg2.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = fg2;
        ctx.beginPath(); ctx.arc(fl.x, fl.y, fl.r * 1.2, 0, Math.PI * 2); ctx.fill();
      }

      // particles
      for (var p2 = 0; p2 < particles.length; p2++) {
        var pt = particles[p2], la = Math.max(0, pt.life);
        ctx.save();
        ctx.globalAlpha = la;
        ctx.fillStyle = 'rgba(' + pt.col + ',.35)';
        ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.r * 2.1, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgb(' + pt.col + ')';
        if (pt.sq) {
          ctx.translate(pt.x, pt.y); ctx.rotate(pt.rot);
          ctx.fillRect(-pt.r, -pt.r, pt.r * 2, pt.r * 2);
        } else {
          ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.r, 0, Math.PI * 2); ctx.fill();
        }
        ctx.restore();
      }

      // floating text
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (var k = 0; k < floaters.length; k++) {
        var ft = floaters[k];
        var age = 1 - ft.life;
        var sc2 = ft.pop ? (age < 0.22 ? easeOutBack(age / 0.22) : 1.06 - 0.06 * Math.sin((age - 0.22) * 8)) : 1;
        ctx.save();
        ctx.globalAlpha = clamp(ft.life * 1.6, 0, 1);
        ctx.translate(ft.x, ft.y);
        ctx.scale(sc2, sc2);
        ctx.font = '900 ' + Math.round(CELL * ft.sz) + 'px system-ui,-apple-system,Segoe UI,Roboto,sans-serif';
        ctx.lineJoin = 'round';
        ctx.lineWidth = Math.max(3, CELL * 0.12);
        ctx.strokeStyle = 'rgba(12,6,32,.8)';
        ctx.strokeText(ft.text, 0, 0);
        var tg = ctx.createLinearGradient(0, -CELL * ft.sz * 0.5, 0, CELL * ft.sz * 0.5);
        tg.addColorStop(0, '#ffffff'); tg.addColorStop(1, ft.col === '#fff' ? '#ffe27a' : ft.col);
        ctx.fillStyle = tg;
        ctx.fillText(ft.text, 0, 0);
        ctx.restore();
      }
      ctx.globalAlpha = 1;

      if (banner) {
        var age2 = 1 - banner.life;
        var bs = age2 < 0.2 ? easeOutBack(age2 / 0.2) : 1 + 0.05 * Math.sin((age2 - 0.2) * 9);
        ctx.save();
        ctx.globalAlpha = clamp(banner.life * 2.2, 0, 1);
        ctx.translate(BW / 2, BH * 0.44);
        ctx.scale(bs, bs);
        ctx.font = '900 ' + Math.round(CELL * 0.78) + 'px system-ui,-apple-system,Segoe UI,Roboto,sans-serif';
        ctx.lineJoin = 'round';
        ctx.lineWidth = Math.max(5, CELL * 0.2);
        ctx.strokeStyle = 'rgba(10,4,28,.85)';
        ctx.strokeText(banner.text, 0, 0);
        var bgg = ctx.createLinearGradient(-BW * 0.4, 0, BW * 0.4, 0);
        bgg.addColorStop(0, '#fff6a8'); bgg.addColorStop(0.35, '#ffd93d');
        bgg.addColorStop(0.7, '#ff7ab8'); bgg.addColorStop(1, '#7ae7ff');
        ctx.fillStyle = bgg;
        ctx.fillText(banner.text, 0, 0);
        ctx.restore();
      }
      ctx.restore(); // board clip

      if (flashAll > 0.01) {
        ctx.fillStyle = 'rgba(255,255,255,' + (flashAll * 0.5).toFixed(3) + ')';
        ctx.fillRect(0, 0, W, H);
      }
      ctx.restore(); // shake

      if (dead) {
        ctx.save();
        ctx.fillStyle = 'rgba(8,5,22,.78)';
        ctx.fillRect(0, 0, W, H);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = '900 ' + Math.round(CELL * 0.62) + 'px system-ui,sans-serif';
        ctx.fillStyle = '#fff';
        ctx.fillText('OUT OF MOVES', W / 2, H / 2 - CELL * 0.32);
        ctx.font = '700 ' + Math.round(CELL * 0.34) + 'px system-ui,sans-serif';
        ctx.fillStyle = '#ffd93d';
        ctx.fillText('Score ' + score + ' · Level ' + level, W / 2, H / 2 + CELL * 0.32);
        ctx.restore();
      }
    }

    // ---------- loop ----------
    function settled() {
      for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
        var t = grid[r][c];
        if (!t) continue;
        if (Math.abs(t.px - cellCX(r, c)) > 0.7 || Math.abs(t.py - cellCY(r)) > 0.7) return false;
        if (Math.abs(t.vy) > 0.7) return false;
      }
      return true;
    }

    var last = 0;
    function loop(now) {
      var dt = last ? clamp((now - last) / 16.67, 0.5, 3) : 1;
      last = now;
      if (paused) { draw(now); raf = requestAnimationFrame(loop); return; }

      for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
        var t = grid[r][c];
        if (!t) continue;
        var tx = cellCX(r, c), ty = cellCY(r);

        if (state === 'swap' || state === 'swapback') {
          t.px += (tx - t.px) * Math.min(1, 0.3 * dt);
          t.py += (ty - t.py) * Math.min(1, 0.3 * dt);
          t.vy = 0;
        } else {
          if (Math.abs(t.px - tx) > 0.4) t.px += (tx - t.px) * Math.min(1, 0.28 * dt);
          else t.px = tx;
          if (t.py < ty - 0.4) {
            t.vy = Math.min(t.vy + 2.6 * dt, 26);
            t.py += t.vy * dt;
            if (t.py >= ty) {
              t.py = ty;
              if (t.vy > 6) { t.vy = -t.vy * 0.22; t.sx = 1.2; t.sy = 0.8; beep(180 + Math.random() * 40, 0.03, 'sine'); }
              else t.vy = 0;
            }
            var sp = Math.min(0.12, Math.abs(t.vy) * 0.006);
            t.sy = 1 - sp; t.sx = 1 + sp;
          } else { t.py = ty; t.vy = 0; }
        }

        t.sx += (1 - t.sx) * Math.min(1, 0.22 * dt);
        t.sy += (1 - t.sy) * Math.min(1, 0.22 * dt);

        if (sel && grid[sel.r] && grid[sel.r][sel.c] === t && state === 'idle') {
          t.hop += (CELL * 0.12 - t.hop) * Math.min(1, 0.2 * dt);
        } else if (t.hop > 0.2) {
          t.hop += (0 - t.hop) * Math.min(1, 0.25 * dt);
        } else t.hop = 0;

        if (t.die > 0) t.die += 0.115 * dt;
      }

      var i;
      for (i = particles.length - 1; i >= 0; i--) {
        var p = particles[i];
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 0.28 * dt;
        p.vx *= 0.985; p.rot += p.vr * dt; p.life -= 0.026 * dt;
        if (p.life <= 0) particles.splice(i, 1);
      }
      for (i = floaters.length - 1; i >= 0; i--) {
        floaters[i].y -= 0.85 * dt; floaters[i].life -= 0.019 * dt;
        if (floaters[i].life <= 0) floaters.splice(i, 1);
      }
      for (i = rings.length - 1; i >= 0; i--) {
        rings[i].life -= 0.05 * dt;
        if (rings[i].life <= 0) rings.splice(i, 1);
      }
      for (i = beams.length - 1; i >= 0; i--) {
        beams[i].life -= 0.055 * dt;
        if (beams[i].life <= 0) beams.splice(i, 1);
      }
      for (i = flashes.length - 1; i >= 0; i--) {
        flashes[i].life -= 0.12 * dt;
        if (flashes[i].life <= 0) flashes.splice(i, 1);
      }
      if (banner) { banner.life -= 0.016 * dt; banner.age += dt; if (banner.life <= 0) banner = null; }
      if (shake > 0) shake = Math.max(0, shake - 0.7 * dt);
      if (flashAll > 0) flashAll = Math.max(0, flashAll - 0.06 * dt);

      if (!dead) {
        if (state === 'swap' || state === 'swapback') {
          if (settled()) resolve();
        } else if (state === 'clearing') {
          var pending = false;
          for (var r2 = 0; r2 < ROWS; r2++) for (var c2 = 0; c2 < COLS; c2++) {
            var t2 = grid[r2][c2];
            if (t2 && t2.die > 0 && t2.die < 1) pending = true;
          }
          if (!pending) {
            for (var r3 = 0; r3 < ROWS; r3++) for (var c3 = 0; c3 < COLS; c3++) {
              if (grid[r3][c3] && grid[r3][c3].die > 0) grid[r3][c3] = null;
            }
            applyGravity();
          }
        } else if (state === 'falling') {
          if (settled()) {
            var g = findMatches();
            if (g.length) { combo++; resolve(); }
            else { state = 'idle'; endOfCascade(); }
          }
        }
      }

      draw(now);
      raf = requestAnimationFrame(loop);
    }

    // ---------- sizing ----------
    function layout() {
      var w = host.clientWidth || 360;
      CELL = Math.max(26, Math.floor(Math.min(w, 460) / (COLS + 0.55)));
      PAD = Math.max(6, Math.round(CELL * 0.24));
      BW = CELL * COLS;
      computeRows();
      W = BW + PAD * 2; H = BH + PAD * 2;
      ctx = MA.fitCanvas(cv, W, H);
      for (var r = 0; r < ROWS; r++) {
        if (!grid[r]) continue;
        for (var c = 0; c < COLS; c++) {
          var t = grid[r][c];
          if (t) { t.px = cellCX(r, c); t.py = cellCY(r); }
        }
      }
      buildSprites();
    }

    var rt = null;
    function onResize() {
      clearTimeout(rt);
      rt = setTimeout(function () {
        var old = CELL;
        layout();
        if (old !== spriteFor) buildSprites();
      }, 120);
    }
    window.addEventListener('resize', onResize);

    MA._match3Cleanup = function () { cancelAnimationFrame(raf); window.removeEventListener('resize', onResize); };

    MA._match3Debug = function () {
      return {
        grid: grid, findMatches: findMatches, hasMove: hasMove,
        st: function () { return state; }, score: function () { return score; },
        moves: function () { return moves; }, cell: CELL, COLS: COLS, ROWS: ROWS,
        spriteInfo: spriteInfo,
        swap: function (a, b) { tryMove(a, b); }
      };
    };

    computeRows();
    layout();
    reset();

    // Playgama Bridge init — safe no-op when the SDK is absent (public site / mock mode).
    (function () {
      var b = window.bridge;
      if (!b) return;
      try {
        b.initialize().then(function () {
          try { if (b.platform && b.platform.isAudioEnabled === false) sound = false; } catch (e) { }
          if (b.platform && b.EVENT_NAME) {
            b.platform.on(b.EVENT_NAME.AUDIO_STATE_CHANGED, function (on) { if (!on) sound = false; });
            b.platform.on(b.EVENT_NAME.PAUSE_STATE_CHANGED, function (p) { paused = !!p; });
          }
          try { if (b.platform) b.platform.sendMessage('game_ready'); } catch (e) { }
          MA._refreshHud = setHud;
          MA.loadBestFromBridge('match3');
        }).catch(function () { });
      } catch (e) { }
    })();

    raf = requestAnimationFrame(loop);
  };
})(window.MiniArcade);
